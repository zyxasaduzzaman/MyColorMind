from colorMind import ColorMind


