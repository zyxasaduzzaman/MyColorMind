from .colorMind import ColorMind

__all__ = ["ColorMind"]
